import xbmcaddon

MainBase = 'https://goo.gl/6lJSRB'
addon = xbmcaddon.Addon('plugin.video.oursports')